package test;

public class Foo {
    protected int result = 20;
    int value = 10;
}