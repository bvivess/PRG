package com.example.review;

public class IfElse {

    public static void main(String args[]){
        long a = 1;
        long b = 2;
        
        if (a == b){
            System.out.println("True");
        } else {
            System.out.println("False");
        }
        
    }
}
