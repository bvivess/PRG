package com.example;

public final class FinalParentClass { }
