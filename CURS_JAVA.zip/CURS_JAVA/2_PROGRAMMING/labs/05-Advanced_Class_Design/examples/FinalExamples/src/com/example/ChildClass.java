package com.example;

// compile time error
public class ChildClass extends FinalParentClass { }
