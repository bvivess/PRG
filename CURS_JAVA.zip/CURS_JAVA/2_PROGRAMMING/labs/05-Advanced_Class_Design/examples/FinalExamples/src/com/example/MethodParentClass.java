package com.example;

public class MethodParentClass {
    public final void printMessage() {
        System.out.println("This is a final method");
    }
}