package example.com;

import static java.lang.Math.random;
import static java.lang.Math.*;

public class StaticImportClass {
    public static void main(String[] args) {
        double d = random();
    }
}