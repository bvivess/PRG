package com.example;

public class ComplexEnumsMain {

    public static void main(String[] args) {
        Computer comp = new Computer();
        comp.setState(PowerState.SUSPEND);
    }
}