/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */

public class DateTwoTest {
  public static void main(String args[]) {
         DateTwo date = new DateTwo();
         //date.day = 16;
         //date.month = 10;
         //date.year = 2011;    
  }// end main
    
} // end class

