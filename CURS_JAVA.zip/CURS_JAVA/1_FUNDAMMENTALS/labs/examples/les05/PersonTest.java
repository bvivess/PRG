class PersonTest {
   
  public static void main (String args[]) {
 
  Person myPerson = new Person();
  
  myPerson.calculateAge();

  } 
}
