public class IfElseElevatorTest {

   public static void main(String args[]) {
     
    IfElseElevator myIfElseElevator = new IfElseElevator();
     
     myIfElseElevator.openDoor();
     myIfElseElevator.closeDoor();
     myIfElseElevator.goDown();
     myIfElseElevator.goUp();
     myIfElseElevator.goUp();
     myIfElseElevator.goUp();
     myIfElseElevator.openDoor();
     myIfElseElevator.closeDoor();
     myIfElseElevator.goDown();
     myIfElseElevator.openDoor();
     myIfElseElevator.closeDoor();
     myIfElseElevator.goDown();
     myIfElseElevator.openDoor();
   }
}
