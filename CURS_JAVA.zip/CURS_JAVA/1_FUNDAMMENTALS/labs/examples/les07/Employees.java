public class Employees {

  public String name1 = "Fred Smith";
  public String name2 = "Joseph Smith";
    
  public void areNamesEqual() {
     
    if (name1.equals(name2)) {
      System.out.println("Same name.");
    }
    else {
      System.out.println("Different name.");
    }
  }
}
