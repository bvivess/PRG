
import java.io.File;
import java.io.IOException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kennys
 */
public class TestException {
    public static void main (String args[]) throws IOException {

        TestArray myTestArray = new TestArray(5);
        
        myTestArray.addElement(5, 23);
           
    }

}
