


import java.io.File;
import java.io.IOException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kennys
 */
public class TestArrayException {
    public static void main (String args[]) throws IOException {

        ArrayException myTestArray = new ArrayException(5);
        
        myTestArray.addElement(5, 23);
           
    }

}
