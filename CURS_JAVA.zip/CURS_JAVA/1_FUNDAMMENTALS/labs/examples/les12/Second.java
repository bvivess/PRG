


public class Second {

    public String toString() {
        return "This class named Second has overridden the toString() method of Object";
    }

}
