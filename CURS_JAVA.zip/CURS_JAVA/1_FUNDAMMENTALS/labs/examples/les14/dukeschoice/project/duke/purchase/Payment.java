package duke.purchase;

public class Payment { 
}
