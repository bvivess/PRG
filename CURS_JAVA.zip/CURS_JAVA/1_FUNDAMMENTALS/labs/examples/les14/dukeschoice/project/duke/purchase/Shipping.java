package duke.purchase;

public class Shipping {
}



