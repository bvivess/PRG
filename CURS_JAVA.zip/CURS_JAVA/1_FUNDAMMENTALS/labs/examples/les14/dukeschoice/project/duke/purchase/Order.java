package duke.purchase;

public class Order {
}
