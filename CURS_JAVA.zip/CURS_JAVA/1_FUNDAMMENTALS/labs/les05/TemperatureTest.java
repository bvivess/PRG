public class TemperatureTest {
   
  public static void main (String args[]) {
 
  Temperature myTemperature = new Temperature();
  
  myTemperature.calculateCelsius();

  } 
}
